<?php

namespace App\Http\Controllers\Api;

use App\Models\Student;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;

class StudentController extends Controller
{
    public function index()
        {
           $students = Student::all();
           if($students->count() > 0){
           
         
           return response()->json([
            'status' => 200,
            'students' => $students
           ], 200);

        }
        else
        {
            return response()->json([
                'status' => 404,
                'message' => 'No Records Found'
               ], 404);
        }
           
        }
        public function store(Request $request)
    {

		$validate=Validator::make($request->all(),[
            'name'=>'Required|string|max:191',
            'course'=>'Required|string|max:191',
            'email'=>'Required|email|max:191',
            'phone'=>'Required|min:11|numeric'
			
        ]);
		
		if($validate->fails())
		{
			return response()->json([
				'status' => 422, 
				'errors' => $validate->messages()
            ], 422);
		}
		else
		{
			$data=new student;
			$data->name=$request->name;
            $data->course=$request->course;
			$data->email=$request->email;
            $data->phone=$request->phone;
			
			$data->save();
			return response()->json([
			'status'=>200,
			
			'message' => "Student Register Successfully"
			],200);
           
			
    }
}
        public function show($id)
        {
            $student = Student::find($id);
            if($student){
                return response()->json([
                    'status' => 200,
                    'student' => $student
                ], 200);

            }else{
                return response()->json([
                    'status' => 404,
                    'message' => "No Student found!"
                ],404);
            }

        }

        public function edit($id){

            $student = Student::find($id);
            if($student){
                return response()->json([
                    'status' => 200,
                    'student' => $student
                ], 200);

            }else{
                return response()->json([
                    'status' => 404,
                    'message' => "No Student found!"
                ],404);
            }

        }

        public function update(Request $request, $id)
        {
            $validate=Validator::make($request->all(),[
                'name'=>'Required|string|max:191',
                'course'=>'Required|string|max:191',
                'email'=>'Required|email|max:191',
                'phone'=>'Required|min:11|numeric'
            ]);
                
            if($validate->fails())
		{
			return response()->json([
				'status' => 422, 
				'errors' => $validate->messages()
            ], 422);
		}
		else
		{
			
          
			$data=student::find($id);

			$data->name=$request->name;
            $data->course=$request->course;
			$data->email=$request->email;
            $data->phone=$request->phone;
			
			$data->update();
			return response()->json([
			'status'=>200,
			'message'=>"Student Data Updated Successfully"
			]);
			
        }



        }

        public function destroy($id)
        {
            student::find($id)->delete();
            return response()->json([
                'status'=>200,
                'messgage'=>"Student Record Deleted Successfully"
            ]);
        }
}